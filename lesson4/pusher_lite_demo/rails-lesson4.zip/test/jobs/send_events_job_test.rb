require 'test_helper'

class SendEventsJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
